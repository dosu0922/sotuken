/**
 * 
 */
// スクロール位置をCookieに保存
function saveScrollPosition() {
    var scrollPosition = $('.scroll').scrollLeft();
    document.cookie = 'scrollPosition=' + scrollPosition + '; path=/';
}

// ページ離脱時にスクロール位置を保存
window.addEventListener('beforeunload', saveScrollPosition);

// Cookieからスクロール位置を取得して設定
function restoreScrollPosition() {
    var cookieValue = document.cookie.replace(/(?:(?:^|.*;\s*)scrollPosition\s*=\s*([^;]*).*$)|^.*$/, "$1");
    var savedScrollPosition = parseInt(cookieValue, 10);

    if (!isNaN(savedScrollPosition)) {
        $('.scroll').scrollLeft(savedScrollPosition);
    }
}

// ページ読み込み時にスクロール位置を復元
window.addEventListener('load', restoreScrollPosition);
