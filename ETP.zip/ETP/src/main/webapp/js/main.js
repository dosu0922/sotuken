/**
 * 
 */


//入れる画像を定義
let maruimg = $('<img>', {
	id: 'maru',
	src: '/ETP/image/maru.png',
	alt: '正解',
	width: '40px',
	height: '40px'
});

let batsuimg = $('<img>', {
	id: 'batsu',
	src: '/ETP/image/batsu.png',
	alt: '不正解',
	width: '40px',
	height: '40px'
});
let isClicked = false; // クリック済みのフラグ
	
// クリックされたボタンが正解かどうかを判定する関数
function checkAnswer(clickedId) {
	console.log(isClicked);
	if (!isClicked) { // クリックされていない場合に処理を実行
	
		// スクリプトが実行されるときにcorrectAnswerの値を取得
		let correctAnswer = document.getElementById('correctAnswer').value;
		let userAnswer = document.getElementById('userAnswer');
		
		if (clickedId == correctAnswer) {
	 		$('.answerimg').replaceWith(maruimg);
			$('#showAnswerBtn').hide();
			$('#answerChar').show();
			$('#userAnswer').val('maru');
		} else {
			$('.answerimg').replaceWith(batsuimg);
			$('#showAnswerBtn').hide();
			$('#answerChar').show();
			$('#userAnswer').val('batsu');
		}
	isClicked = true; // クリック済みのフラグを立てる
	}
}



document.addEventListener('DOMContentLoaded', function() {
	let correctAnswer = document.getElementById('correctAnswer').value;
	let answerChar = document.getElementById('answerChar');
	
	if(correctAnswer == 'a'){
		answerChar.innerHTML = 'ア';
	} else if(correctAnswer == 'i'){
		answerChar.innerHTML = 'イ';
	} else if(correctAnswer == 'u'){
		answerChar.innerHTML = 'ウ';
	} else if(correctAnswer == 'e'){
		answerChar.innerHTML = 'エ';
	}
});