/**
 * 
 */
$(document).ready(function() {
    // ページが読み込まれた後に実行されるコード

    // シリーズごとの文字列と対応する <p> 要素のセレクタを定義
    var seriesData = [
        { series: 'テクノロジ系', selector: '.technology' },
        { series: 'マネジメント系', selector: '.management' },
        { series: 'ストラテジ系', selector: '.strategy' }
    ];

    seriesData.forEach(function(data) {
        // シリーズごとの文字数をカウント
        var totalOccurrences = 0;
        $('.table-frame td').each(function() {
            var targetString = data.series;
            var occurrences = ($(this).text().match(new RegExp(targetString, 'g')) || []).length;
            totalOccurrences += occurrences;
        });

        var correctSeries = 0;
        $('.table-frame tr').each(function() {
            var targetString = data.series;

            // 同じ行の .correctness クラスを持つ <td> 要素に対して処理
            var occurrences = $(this).find('.correctness').filter(function() {
                return $(this).text().trim() === '〇' && $(this).siblings('td:contains("' + targetString + '")').length > 0;
            }).length;

            correctSeries += occurrences;
        });

        // シリーズごとの総数を対応する <p> 要素に挿入
        $(data.selector).text(correctSeries + '問 / ' + totalOccurrences + '問');
    });
});