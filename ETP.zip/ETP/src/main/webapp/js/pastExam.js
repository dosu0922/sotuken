/**
 * 
 */

function showAnswer() {
	$('#showAnswerBtn').hide();
	$('#answerChar').show();
}
