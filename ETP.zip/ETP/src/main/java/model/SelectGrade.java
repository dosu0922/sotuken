package model;

import java.util.ArrayList;
import java.util.List;

import dao.GradeDAO;

public class SelectGrade {
	public List<Grade> selectGrade (int gradeId) {
		List<Grade> gradeList = new ArrayList<Grade>();
		GradeDAO dao = new GradeDAO();
		gradeList = dao.gradeDisplay(gradeId);
		
		return gradeList;
	}
	
	public List<Grade> selectGrade (String studentMail) {
		List<Grade> gradeList = new ArrayList<Grade>();
		GradeDAO dao = new GradeDAO();
		gradeList = dao.gradeDisplay(studentMail);
		
		return gradeList;
	}
	
	public List<Integer> selectGradeId (String studentMail) {
		List<Integer> gradeIdList = new ArrayList<Integer>();
		GradeDAO dao = new GradeDAO();
		gradeIdList = dao.studentGradeId(studentMail);
		
		return gradeIdList;
	}
	
	public List<Grade> filterGrade (String studentMail, int gradeId) {
		List<Grade> gradeList = new ArrayList<Grade>();
		GradeDAO dao = new GradeDAO();
		gradeList = dao.filterGradeDisplay(studentMail, gradeId);
		
		return gradeList;
	}
}
