package model;

import dao.PastExamDAO;

public class SelectCorrectRate {
	public CorrectRate selectCorrectRate(String ysen) {
		CorrectRate correctRate = null;
		PastExamDAO dao = new PastExamDAO();
		correctRate = dao.selectCorrectRate(ysen);
		
		return correctRate;
	}
}
