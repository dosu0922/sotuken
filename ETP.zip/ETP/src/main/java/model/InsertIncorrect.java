package model;

import java.util.List;

import dao.IncorrectDAO;

public class InsertIncorrect {
	public void incorrectInsert(List<Mock> mockList) {
		for(Mock mock : mockList) {
			if(!(mock.getAnswer().equals(mock.getUserAnswer()))) {
				IncorrectDAO dao = new IncorrectDAO();
				dao.incorrectInsert(mock);
			}
		}

	}
}
