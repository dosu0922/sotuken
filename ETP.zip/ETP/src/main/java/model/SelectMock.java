package model;

import java.util.List;

import dao.MockDAO;

public class SelectMock {
	public List<Mock> selectMock(int mockId){
		MockDAO dao = new MockDAO();
		List<Mock> mockList = dao.selectMock(mockId);
		
		return mockList;
	}
}
