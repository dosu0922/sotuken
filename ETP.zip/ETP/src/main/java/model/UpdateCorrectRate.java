package model;

import java.util.List;

import dao.PastExamDAO;

public class UpdateCorrectRate {
	public void updateCorrectRate(List<Mock> mockList) {
		PastExamDAO dao = new PastExamDAO();
		
		for(Mock mock : mockList) {
			dao.UpdateCorrectRate(mock);
		}
	}
}
