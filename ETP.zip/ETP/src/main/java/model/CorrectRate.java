package model;

import java.io.Serializable;

public class CorrectRate implements Serializable{
	private int correctCount;
	private int answeredCount;
	
	public CorrectRate() {
		super();
	}
	
	public CorrectRate(int correctCount, int answeredCount) {
		super();
		this.correctCount = correctCount;
		this.answeredCount = answeredCount;
	}

	public int getCorrectCount() {
		return correctCount;
	}

	public int getAnsweredCount() {
		return answeredCount;
	}
	
	
}
