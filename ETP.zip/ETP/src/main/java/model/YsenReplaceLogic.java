package model;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class YsenReplaceLogic {
    public String ysenReplace(String ysen) {
    	 // AM_ を削除
        ysen = ysen.replace("AM_", "");
        System.out.println(ysen);
        
        // 正規表現を使用して置換 (\d は数字にマッチ)
        Pattern pattern = Pattern.compile("R(\\d*)_(A|S)(\\d*)");
        Matcher matcher = pattern.matcher(ysen);
        
        String result = "";

        if (matcher.find()) {
            String year = matcher.group(1);
            String season = matcher.group(2);
            String examNo = removeLeadingZeros(matcher.group(3));
            // グループに基づいて置換を行う
            String replacement;
            if (season.equals("A")) {
                replacement = year + "_aki/" + examNo;
            } else {
                replacement = year + "_haru/"+ examNo;
            }
            result += replacement;
        }
        return result;
    }
    
    // 余分なゼロを削除するメソッド
    private String removeLeadingZeros(String input) {
        return input.replaceFirst("^0+(?!$)", "");
    }
    
	public String yearAndExamNoReplace(String year, String examNo) {
		//年度と問番号をAM_R00_S00の形に変更
		String[] inputYear = year.split("_");
		
		String year1 = inputYear[0]; //05
		String year2 = inputYear[1]; //haru or aki
		String ysen = "";
		
		//exam_noが1から9の場合
        if (Integer.parseInt(examNo) >= 1 && Integer.parseInt(examNo) <= 9) {
            examNo = String.format("%02d", Integer.parseInt(examNo));

        } 
		
		if(Integer.parseInt(year1) <= 5) {
			if(year2.equals("haru")) {
				ysen = "AM_R" + year1 + "_S" + examNo;
			} else {
				ysen = "AM_R" + year1 + "_A" + examNo;
			}
		} else {
			if(year2.equals("haru")) {
				ysen = "AM_H" + year1 + "_S" + examNo;
			} else {
				ysen = "AM_H" + year1 + "_A" + examNo;
			}
		}
		System.out.println("YSEN：" + ysen);
		return ysen;
		
	}
}
