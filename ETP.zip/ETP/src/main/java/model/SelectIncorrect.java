package model;

import java.util.ArrayList;
import java.util.List;

import dao.IncorrectDAO;

public class SelectIncorrect {
	public List<Incorrect> selectIncorrect(String studentMail){
		List<Incorrect> incorrectList = new ArrayList<Incorrect>();
		IncorrectDAO dao = new IncorrectDAO();
		incorrectList = dao.incorrectDisplay(studentMail);
		
		return incorrectList;
	}
	
	public List<Incorrect> incorrectGrade (int gradeId, String studentMail) {
		List<Incorrect> incorrectList = new ArrayList<Incorrect>();
		IncorrectDAO dao = new IncorrectDAO();
		incorrectList = dao.selectIncorrect(gradeId, studentMail);
		
		return incorrectList;
	}
}
