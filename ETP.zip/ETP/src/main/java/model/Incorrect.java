package model;

import java.io.Serializable;

public class Incorrect implements Serializable{
	private String studentMail;
	private String correctness;
	private String ysen;
	
	public Incorrect(String studentMail, String correctness, String ysen) {
		super();
		this.studentMail = studentMail;
		this.correctness = correctness;
		this.ysen = ysen;
	}

	public String getStudentMail() {
		return studentMail;
	}

	public String getCorrectness() {
		return correctness;
	}

	public String getYsen() {
		return ysen;
	}
	
	
}
