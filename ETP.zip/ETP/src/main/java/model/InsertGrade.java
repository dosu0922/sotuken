package model;

import java.util.List;

import dao.GradeDAO;

public class InsertGrade {
	public void insertGrade(List<Mock> mockList) {
		GradeDAO dao = new GradeDAO();
		for(Mock mock : mockList) {
			dao.insertGrade(mock);
		}
	}
}
