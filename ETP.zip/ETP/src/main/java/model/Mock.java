package model;

import java.io.Serializable;

public class Mock implements Serializable{
	private int mockId;
	private String studentMail;
	private int mockNo;
	private String ysen;
	private String field;
	private String middleCategory;
	private String smallCategory;
	private String answer;
	private String userAnswer;
	private int isAnswered;

	public Mock(int mockId, String studentMail, int mockNo, String ysen, String field, String middleCategory,
			String smallCategory, String answer, String userAnswer, int isAnswered) {
		super();
		this.mockId = mockId;
		this.studentMail = studentMail;
		this.mockNo = mockNo;
		this.ysen = ysen;
		this.field = field;
		this.middleCategory = middleCategory;
		this.smallCategory = smallCategory;
		this.answer = answer;
		this.userAnswer = userAnswer;
		this.isAnswered = isAnswered;
	}

	public int getMockId() {
		return mockId;
	}

	public String getStudentMail() {
		return studentMail;
	}

	public int getMockNo() {
		return mockNo;
	}

	public String getYsen() {
		return ysen;
	}

	public String getField() {
		return field;
	}

	public String getMiddleCategory() {
		return middleCategory;
	}

	public String getSmallCategory() {
		return smallCategory;
	}

	public String getAnswer() {
		return answer;
	}

	public String getUserAnswer() {
		return userAnswer;
	}

	public int getIsAnswered() {
		return isAnswered;
	}

	public void setUserAnswer(String userAnswer) {
		this.userAnswer = userAnswer;
	}

	public void setIsAnswered(int isAnswered) {
		this.isAnswered = isAnswered;
	}
	
	
}
