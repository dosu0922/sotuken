package model;

import dao.MockDAO;

public class UpdateMock {
	public void updateUserAnswer(int mockId, String userAnswer, int mockNo) {
		MockDAO dao = new MockDAO();
		dao.updateUserAnswer(mockId, userAnswer, mockNo);
	}
}
