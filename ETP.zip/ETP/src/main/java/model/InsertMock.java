package model;

import java.util.List;

import dao.MockDAO;

public class InsertMock {
	public void insertMock(List<Mock> mockList) {
		MockDAO dao = new MockDAO();
		for(Mock mock : mockList) {
			dao.mockInsert(mock);
		}
	}
}
