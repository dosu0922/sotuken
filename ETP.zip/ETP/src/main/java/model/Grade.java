package model;

import java.io.Serializable;

public class Grade implements Serializable{
	private int gradeId;
	private String studentMail;
	private int mockNo;
	private String correnctness;
	private String field;
	private String middleCategory;
	private String smallCategory;
	private String ysen;
	
	public Grade() {
		super();
	}

	public Grade(int gradeId, String studentMail, int mockNo, String correnctness, String field, String middleCategory,
			String smallCategory, String ysen) {
		super();
		this.gradeId = gradeId;
		this.studentMail = studentMail;
		this.mockNo = mockNo;
		this.correnctness = correnctness;
		this.field = field;
		this.middleCategory = middleCategory;
		this.smallCategory = smallCategory;
		this.ysen = ysen;
	}

	public int getGradeId() {
		return gradeId;
	}

	public String getStudentMail() {
		return studentMail;
	}

	public int getMockNo() {
		return mockNo;
	}

	public String getCorrenctness() {
		return correnctness;
	}

	public String getField() {
		return field;
	}

	public String getMiddleCategory() {
		return middleCategory;
	}

	public String getSmallCategory() {
		return smallCategory;
	}

	public String getYsen() {
		return ysen;
	}
}
