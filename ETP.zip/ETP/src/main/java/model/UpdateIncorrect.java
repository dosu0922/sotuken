package model;

import dao.IncorrectDAO;

public class UpdateIncorrect {
	public void correctUpdate(Incorrect incorrect) {
		IncorrectDAO dao = new IncorrectDAO();
		dao.correctUpdate(incorrect);
	}
}
