package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.CorrectRate;
import model.Mock;

public class PastExamDAO extends DAOParam{
	public void UpdateCorrectRate(Mock mock) {
		// データベースへ接続
		try (Connection conn = DriverManager.getConnection(
		        JDBC_URL, DB_USER, DB_PASS)) {
			String sql = "";
			
			if(mock.getAnswer().equals(mock.getUserAnswer())) {
				sql = "UPDATE am_past_exam "
					+ "SET correct_count = correct_count + 1, answered_count = answered_count + 1 "
					+ "WHERE am_year_season_exam_number = ?";
			} else {
				sql = "UPDATE am_past_exam "
					+ "SET answered_count = answered_count + 1 "
					+ "WHERE am_year_season_exam_number = ?";
			}

			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setString(1, mock.getYsen());
			
			pStmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public CorrectRate selectCorrectRate(String ysen) {
		CorrectRate correctRate = null;
		
		// データベースへ接続
		try (Connection conn = DriverManager.getConnection(
		        JDBC_URL, DB_USER, DB_PASS)) {

			// SELECT文を準備
			String sql = "SELECT correct_count, answered_count FROM am_past_exam WHERE am_year_season_exam_number = ?";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setString(1, ysen);

			// SELECTを実行し、結果表を取得
			ResultSet rs = pStmt.executeQuery();

			while(rs.next()) {
				// 結果表からデータを取得
				int correctCount = rs.getInt("correct_count");
				int answeredCount = rs.getInt("answered_count");
				
				correctRate = new CorrectRate(correctCount, answeredCount);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
			// 見つかったユーザーまたはnullを返す
			return correctRate;
	}
}
