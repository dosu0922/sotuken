package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Grade;
import model.Mock;

public class GradeDAO extends DAOParam{
	public List<Grade> gradeDisplay(int gradeId) {
		List<Grade> gradeList = new ArrayList<Grade>();

		// データベースへ接続
		try (Connection conn = DriverManager.getConnection(
		        JDBC_URL, DB_USER, DB_PASS)) {

			// SELECT文を準備
			String sql = "SELECT * FROM grade WHERE grade_id = ? AND mock_no <> 0";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setInt(1, gradeId);

			// SELECTを実行し、結果表を取得
			ResultSet rs = pStmt.executeQuery();

			while(rs.next()) {
				// 結果表からデータを取得
				String studentMail = rs.getString("student_Mail");
				int mockNo = rs.getInt("mock_no");
				String correctness = rs.getString("correctness");
				String field = rs.getString("field");
				String middleCategory = rs.getString("middle_category");
				String smallCategory = rs.getString("small_category");
				String ysen = rs.getString("am_year_season_exam_number");
				Grade grade = new Grade(gradeId, studentMail, mockNo, correctness, field, middleCategory, smallCategory, ysen);
				
				gradeList.add(grade);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
			// 見つかったユーザーまたはnullを返す
			return gradeList;
	}
	
	public List<Grade> gradeDisplay(String studentMail) {
		List<Grade> gradeList = new ArrayList<Grade>();

		// データベースへ接続
		try (Connection conn = DriverManager.getConnection(
		        JDBC_URL, DB_USER, DB_PASS)) {

			// SELECT文を準備
			String sql = "SELECT * FROM grade WHERE student_mail = ? AND mock_no <> 0";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setString(1, studentMail);

			// SELECTを実行し、結果表を取得
			ResultSet rs = pStmt.executeQuery();

			// 一致したユーザーが存在した場合
			// そのユーザーを表すEmployeeインスタンスを生成
			while(rs.next()) {
				// 結果表からデータを取得
				int gradeId = rs.getInt("grade_id");
				int mockNo = rs.getInt("mock_no");
				String correctness = rs.getString("correctness");
				String field = rs.getString("field");
				String middleCategory = rs.getString("middle_category");
				String smallCategory = rs.getString("small_category");
				String ysen = rs.getString("am_year_season_exam_number");
				Grade grade = new Grade(gradeId, studentMail, mockNo, correctness, field, middleCategory, smallCategory, ysen);
				
				gradeList.add(grade);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
			// 見つかったユーザーまたはnullを返す
			return gradeList;
	}
	
	public void insertGrade(Mock mock) {
		// データベースへ接続
		try (Connection conn = DriverManager.getConnection(
		        JDBC_URL, DB_USER, DB_PASS)) {
			
			// SELECT文を準備
			String sql = "INSERT INTO grade (grade_id, student_mail, mock_no, correctness, field, middle_category, small_category, am_year_season_exam_number, date_time)"
					+ "VALUES(?, ?, ?, ?, ?, ?, ?, ?, '2023-01-01'); ";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			
			pStmt.setInt(1, mock.getMockId());
			pStmt.setString(2, mock.getStudentMail());
			pStmt.setInt(3, mock.getMockNo());
			String correctness = "-";
			if(mock.getAnswer().equals(mock.getUserAnswer())) {
				correctness = "〇";
			} else {
				correctness = "×";
			}
			pStmt.setString(4, correctness);
			pStmt.setString(5, mock.getField());
			pStmt.setString(6, mock.getMiddleCategory());
			pStmt.setString(7, mock.getSmallCategory());
			pStmt.setString(8, mock.getYsen());
			
			pStmt.executeUpdate();
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public List<Integer> studentGradeId(String studentMail) {
		List<Integer> gradeIdList = new ArrayList<Integer>();

		// データベースへ接続
		try (Connection conn = DriverManager.getConnection(
		        JDBC_URL, DB_USER, DB_PASS)) {
			
			// SELECT文を準備
			String sql = "SELECT distinct grade_id FROM grade WHERE student_mail = ?";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setString(1, studentMail);
			
			// SELECTを実行し、結果表を取得
			ResultSet rs = pStmt.executeQuery();

			// 一致したユーザーが存在した場合
			// そのユーザーを表すEmployeeインスタンスを生成
			while(rs.next()) {
				int gradeId = rs.getInt("grade_id");
				gradeIdList.add(gradeId);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
			// 見つかったユーザーまたはnullを返す
			return gradeIdList;
	}
	
	public List<Grade> filterGradeDisplay(String studentMail, int gradeId) {
		List<Grade> gradeList = new ArrayList<Grade>();

		// データベースへ接続
		try (Connection conn = DriverManager.getConnection(
		        JDBC_URL, DB_USER, DB_PASS)) {

			// SELECT文を準備
			String sql = "SELECT * FROM grade WHERE student_mail = ? AND grade_id = ? AND mock_no <> 0";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setString(1, studentMail);
			pStmt.setInt(2, gradeId);

			// SELECTを実行し、結果表を取得
			ResultSet rs = pStmt.executeQuery();

			// 一致したユーザーが存在した場合
			// そのユーザーを表すEmployeeインスタンスを生成
			while(rs.next()) {
				// 結果表からデータを取得
				int mockNo = rs.getInt("mock_no");
				String correctness = rs.getString("correctness");
				String field = rs.getString("field");
				String middleCategory = rs.getString("middle_category");
				String smallCategory = rs.getString("small_category");
				String ysen = rs.getString("am_year_season_exam_number");
				Grade grade = new Grade(gradeId, studentMail, mockNo, correctness, field, middleCategory, smallCategory, ysen);
				
				gradeList.add(grade);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
			// 見つかったユーザーまたはnullを返す
			return gradeList;
	}
}