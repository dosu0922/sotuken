package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Mock;

public class MockDAO extends DAOParam{
	public List<Mock> MockCreate(int mockId, String studentMail) {
		List<Mock> mockList = new ArrayList<Mock>();
		int mockNo = 1;
		
		// データベースへ接続
		try (Connection conn = DriverManager.getConnection(
		        JDBC_URL, DB_USER, DB_PASS)) {

			// SELECT文を準備
		    String kiso = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = '基礎理論' ORDER BY RAND() LIMIT 4";
		    String algo = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = 'アルゴリズムとプログラミング' ORDER BY RAND() LIMIT 4";
		    String comp = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = 'コンピュータ構成要素' ORDER BY RAND() LIMIT 3";
			String syst = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = 'システム構成要素' ORDER BY RAND() LIMIT 3";
			String soft = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = 'ソフトウェア' ORDER BY RAND() LIMIT 4";
		    String hard = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = 'ハードウェア' ORDER BY RAND() LIMIT 4";
			String mult = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = 'マルチメディア' ORDER BY RAND() LIMIT 1";
			String huma = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = 'ヒューマンインタフェース' ORDER BY RAND() LIMIT 1";
		    String data = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = 'データベース' ORDER BY RAND() LIMIT 5";
			String netw = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = 'ネットワーク' ORDER BY RAND() LIMIT 5";
			String secu = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = 'セキュリティ' ORDER BY RAND() LIMIT 11";
			String sode = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = 'ソフトウェア開発管理技術' ORDER BY RAND() LIMIT 3";
            String syde = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = 'システム開発技術' ORDER BY RAND() LIMIT 2";
			String pode = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = 'プロジェクトマネジメント' ORDER BY RAND() LIMIT 4";
			String side = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = 'サービスマネジメント' ORDER BY RAND() LIMIT 3";
			String kans = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = 'システム監査' ORDER BY RAND() LIMIT 3";
	        String gima = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = '技術戦略マネジメント' ORDER BY RAND() LIMIT 2";
			String senr = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = 'システム戦略' ORDER BY RAND() LIMIT 2";
			String kika = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = 'システム企画' ORDER BY RAND() LIMIT 2";
			String kema = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = '経営戦略マネジメント' ORDER BY RAND() LIMIT 4";
			String biji = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = 'ビジネスインダストリ' ORDER BY RAND() LIMIT 3";
			String kats = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = '企業活動' ORDER BY RAND() LIMIT 4";
	        String homu = "SELECT * FROM am_past_exam WHERE am_year_season_exam_number LIKE 'AM_R05%' AND middle_category = '法務' ORDER BY RAND() LIMIT 3";
			
			/*
			String techsql = "SELECT am_year_season_exam_number, field, middle_category, small_category, answer FROM am_past_exam WHERE field = 'T' AND am_year_season_exam_number LIKE 'AM_R05_%' ORDER BY RAND() LIMIT 50";
			String manasql = "SELECT am_year_season_exam_number, field, middle_category, small_category, answer FROM am_past_exam WHERE field = 'M' AND am_year_season_exam_number LIKE 'AM_R05_%' ORDER BY RAND() LIMIT 10";
			String strasql = "SELECT am_year_season_exam_number, field, middle_category, small_category, answer FROM am_past_exam WHERE field = 'S' AND am_year_season_exam_number LIKE 'AM_R05_%' ORDER BY RAND() LIMIT 20";
			*/
			PreparedStatement pStmt = conn.prepareStatement(kiso);

			// SELECTを実行し、結果表を取得
			ResultSet rs = pStmt.executeQuery();

			// 一致したユーザーが存在した場合
			while(rs.next()) {
				// 結果表からデータを取得
				String ysen = rs.getString("am_year_season_exam_number");
				String field = rs.getString("field");
				String middleCategory = rs.getString("middle_category");
				String smallCategory = rs.getString("small_category");
				String answer = rs.getString("answer");
				String userAnswer = "";
				int isAnswered = 0;
				Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
				mockNo++;
				mockList.add(mock);
			}

			pStmt = conn.prepareStatement(algo);

			// SELECTを実行し、結果表を取得
			rs = pStmt.executeQuery();

			// 一致したユーザーが存在した場合
			while(rs.next()) {
				// 結果表からデータを取得
				String ysen = rs.getString("am_year_season_exam_number");
				String field = rs.getString("field");
				String middleCategory = rs.getString("middle_category");
				String smallCategory = rs.getString("small_category");
				String answer = rs.getString("answer");
				String userAnswer = "";
				int isAnswered = 0;
				Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
				mockNo++;
				mockList.add(mock);
			}
			
            pStmt = conn.prepareStatement(comp);

            // SELECTを実行し、結果表を取得
            rs = pStmt.executeQuery();

            // 一致したユーザーが存在した場合
            while(rs.next()) {
                // 結果表からデータを取得
                String ysen = rs.getString("am_year_season_exam_number");
                String field = rs.getString("field");
                String middleCategory = rs.getString("middle_category");
                String smallCategory = rs.getString("small_category");
                String answer = rs.getString("answer");
                String userAnswer = "";
                int isAnswered = 0;
                Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
                mockNo++;
                mockList.add(mock);
            }
            
            pStmt = conn.prepareStatement(syst);

            // SELECTを実行し、結果表を取得
            rs = pStmt.executeQuery();

            // 一致したユーザーが存在した場合
            while(rs.next()) {
                // 結果表からデータを取得
                String ysen = rs.getString("am_year_season_exam_number");
                String field = rs.getString("field");
                String middleCategory = rs.getString("middle_category");
                String smallCategory = rs.getString("small_category");
                String answer = rs.getString("answer");
                String userAnswer = "";
                int isAnswered = 0;
                Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
                mockNo++;
                mockList.add(mock);
            }
            
            pStmt = conn.prepareStatement(soft);

            // SELECTを実行し、結果表を取得
            rs = pStmt.executeQuery();

            // 一致したユーザーが存在した場合
            while(rs.next()) {
                // 結果表からデータを取得
                String ysen = rs.getString("am_year_season_exam_number");
                String field = rs.getString("field");
                String middleCategory = rs.getString("middle_category");
                String smallCategory = rs.getString("small_category");
                String answer = rs.getString("answer");
                String userAnswer = "";
                int isAnswered = 0;
                Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
                mockNo++;
                mockList.add(mock);
            }
            
            pStmt = conn.prepareStatement(hard);

            // SELECTを実行し、結果表を取得
            rs = pStmt.executeQuery();

            // 一致したユーザーが存在した場合
            while(rs.next()) {
                // 結果表からデータを取得
                String ysen = rs.getString("am_year_season_exam_number");
                String field = rs.getString("field");
                String middleCategory = rs.getString("middle_category");
                String smallCategory = rs.getString("small_category");
                String answer = rs.getString("answer");
                String userAnswer = "";
                int isAnswered = 0;
                Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
                mockNo++;
                mockList.add(mock);
            }
            
            pStmt = conn.prepareStatement(mult);

            // SELECTを実行し、結果表を取得
            rs = pStmt.executeQuery();

            // 一致したユーザーが存在した場合
            while(rs.next()) {
                // 結果表からデータを取得
                String ysen = rs.getString("am_year_season_exam_number");
                String field = rs.getString("field");
                String middleCategory = rs.getString("middle_category");
                String smallCategory = rs.getString("small_category");
                String answer = rs.getString("answer");
                String userAnswer = "";
                int isAnswered = 0;
                Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
                mockNo++;
                mockList.add(mock);
            }
            
            pStmt = conn.prepareStatement(huma);

            // SELECTを実行し、結果表を取得
            rs = pStmt.executeQuery();

            // 一致したユーザーが存在した場合
            while(rs.next()) {
                // 結果表からデータを取得
                String ysen = rs.getString("am_year_season_exam_number");
                String field = rs.getString("field");
                String middleCategory = rs.getString("middle_category");
                String smallCategory = rs.getString("small_category");
                String answer = rs.getString("answer");
                String userAnswer = "";
                int isAnswered = 0;
                Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
                mockNo++;
                mockList.add(mock);
            }
            
            pStmt = conn.prepareStatement(data);

            // SELECTを実行し、結果表を取得
            rs = pStmt.executeQuery();

            // 一致したユーザーが存在した場合
            while(rs.next()) {
                // 結果表からデータを取得
                String ysen = rs.getString("am_year_season_exam_number");
                String field = rs.getString("field");
                String middleCategory = rs.getString("middle_category");
                String smallCategory = rs.getString("small_category");
                String answer = rs.getString("answer");
                String userAnswer = "";
                int isAnswered = 0;
                Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
                mockNo++;
                mockList.add(mock);
            }
            
            pStmt = conn.prepareStatement(netw);

            // SELECTを実行し、結果表を取得
            rs = pStmt.executeQuery();

            // 一致したユーザーが存在した場合
            while(rs.next()) {
                // 結果表からデータを取得
                String ysen = rs.getString("am_year_season_exam_number");
                String field = rs.getString("field");
                String middleCategory = rs.getString("middle_category");
                String smallCategory = rs.getString("small_category");
                String answer = rs.getString("answer");
                String userAnswer = "";
                int isAnswered = 0;
                Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
                mockNo++;
                mockList.add(mock);
            }
            
            pStmt = conn.prepareStatement(secu);

            // SELECTを実行し、結果表を取得
            rs = pStmt.executeQuery();

            // 一致したユーザーが存在した場合
            while(rs.next()) {
                // 結果表からデータを取得
                String ysen = rs.getString("am_year_season_exam_number");
                String field = rs.getString("field");
                String middleCategory = rs.getString("middle_category");
                String smallCategory = rs.getString("small_category");
                String answer = rs.getString("answer");
                String userAnswer = "";
                int isAnswered = 0;
                Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
                mockNo++;
                mockList.add(mock);
            }
			
            pStmt = conn.prepareStatement(sode);

            // SELECTを実行し、結果表を取得
            rs = pStmt.executeQuery();

            // 一致したユーザーが存在した場合
            while(rs.next()) {
                // 結果表からデータを取得
                String ysen = rs.getString("am_year_season_exam_number");
                String field = rs.getString("field");
                String middleCategory = rs.getString("middle_category");
                String smallCategory = rs.getString("small_category");
                String answer = rs.getString("answer");
                String userAnswer = "";
                int isAnswered = 0;
                Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
                mockNo++;
                mockList.add(mock);
            }
            
            pStmt = conn.prepareStatement(syde);

            // SELECTを実行し、結果表を取得
            rs = pStmt.executeQuery();

            // 一致したユーザーが存在した場合
            while(rs.next()) {
                // 結果表からデータを取得
                String ysen = rs.getString("am_year_season_exam_number");
                String field = rs.getString("field");
                String middleCategory = rs.getString("middle_category");
                String smallCategory = rs.getString("small_category");
                String answer = rs.getString("answer");
                String userAnswer = "";
                int isAnswered = 0;
                Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
                mockNo++;
                mockList.add(mock);
            }
            
            pStmt = conn.prepareStatement(pode);

            // SELECTを実行し、結果表を取得
            rs = pStmt.executeQuery();

            // 一致したユーザーが存在した場合
            while(rs.next()) {
                // 結果表からデータを取得
                String ysen = rs.getString("am_year_season_exam_number");
                String field = rs.getString("field");
                String middleCategory = rs.getString("middle_category");
                String smallCategory = rs.getString("small_category");
                String answer = rs.getString("answer");
                String userAnswer = "";
                int isAnswered = 0;
                Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
                mockNo++;
                mockList.add(mock);
            }
            
            pStmt = conn.prepareStatement(side);

            // SELECTを実行し、結果表を取得
            rs = pStmt.executeQuery();

            // 一致したユーザーが存在した場合
            while(rs.next()) {
                // 結果表からデータを取得
                String ysen = rs.getString("am_year_season_exam_number");
                String field = rs.getString("field");
                String middleCategory = rs.getString("middle_category");
                String smallCategory = rs.getString("small_category");
                String answer = rs.getString("answer");
                String userAnswer = "";
                int isAnswered = 0;
                Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
                mockNo++;
                mockList.add(mock);
            }
            
            pStmt = conn.prepareStatement(kans);

            // SELECTを実行し、結果表を取得
            rs = pStmt.executeQuery();

            // 一致したユーザーが存在した場合
            while(rs.next()) {
                // 結果表からデータを取得
                String ysen = rs.getString("am_year_season_exam_number");
                String field = rs.getString("field");
                String middleCategory = rs.getString("middle_category");
                String smallCategory = rs.getString("small_category");
                String answer = rs.getString("answer");
                String userAnswer = "";
                int isAnswered = 0;
                Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
                mockNo++;
                mockList.add(mock);
            }
            
            pStmt = conn.prepareStatement(gima);

            // SELECTを実行し、結果表を取得
            rs = pStmt.executeQuery();

            // 一致したユーザーが存在した場合
            while(rs.next()) {
                // 結果表からデータを取得
                String ysen = rs.getString("am_year_season_exam_number");
                String field = rs.getString("field");
                String middleCategory = rs.getString("middle_category");
                String smallCategory = rs.getString("small_category");
                String answer = rs.getString("answer");
                String userAnswer = "";
                int isAnswered = 0;
                Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
                mockNo++;
                mockList.add(mock);
            }
            
            pStmt = conn.prepareStatement(senr);

            // SELECTを実行し、結果表を取得
            rs = pStmt.executeQuery();

            // 一致したユーザーが存在した場合
            while(rs.next()) {
                // 結果表からデータを取得
                String ysen = rs.getString("am_year_season_exam_number");
                String field = rs.getString("field");
                String middleCategory = rs.getString("middle_category");
                String smallCategory = rs.getString("small_category");
                String answer = rs.getString("answer");
                String userAnswer = "";
                int isAnswered = 0;
                Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
                mockNo++;
                mockList.add(mock);
            }
            
            pStmt = conn.prepareStatement(kika);

            // SELECTを実行し、結果表を取得
            rs = pStmt.executeQuery();

            // 一致したユーザーが存在した場合
            while(rs.next()) {
                // 結果表からデータを取得
                String ysen = rs.getString("am_year_season_exam_number");
                String field = rs.getString("field");
                String middleCategory = rs.getString("middle_category");
                String smallCategory = rs.getString("small_category");
                String answer = rs.getString("answer");
                String userAnswer = "";
                int isAnswered = 0;
                Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
                mockNo++;
                mockList.add(mock);
            }

            pStmt = conn.prepareStatement(kema);

            // SELECTを実行し、結果表を取得
            rs = pStmt.executeQuery();

            // 一致したユーザーが存在した場合
            while(rs.next()) {
                // 結果表からデータを取得
                String ysen = rs.getString("am_year_season_exam_number");
                String field = rs.getString("field");
                String middleCategory = rs.getString("middle_category");
                String smallCategory = rs.getString("small_category");
                String answer = rs.getString("answer");
                String userAnswer = "";
                int isAnswered = 0;
                Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
                mockNo++;
                mockList.add(mock);
            }
            
            pStmt = conn.prepareStatement(biji);

            // SELECTを実行し、結果表を取得
            rs = pStmt.executeQuery();

            // 一致したユーザーが存在した場合
            while(rs.next()) {
                // 結果表からデータを取得
                String ysen = rs.getString("am_year_season_exam_number");
                String field = rs.getString("field");
                String middleCategory = rs.getString("middle_category");
                String smallCategory = rs.getString("small_category");
                String answer = rs.getString("answer");
                String userAnswer = "";
                int isAnswered = 0;
                Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
                mockNo++;
                mockList.add(mock);
            }

			pStmt = conn.prepareStatement(kats);

			// SELECTを実行し、結果表を取得
			rs = pStmt.executeQuery();

			// 一致したユーザーが存在した場合
			while(rs.next()) {
				// 結果表からデータを取得
				String ysen = rs.getString("am_year_season_exam_number");
				String field = rs.getString("field");
				String middleCategory = rs.getString("middle_category");
				String smallCategory = rs.getString("small_category");
				String answer = rs.getString("answer");
				String userAnswer = "";
				int isAnswered = 0;
				Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
				mockNo++;
				mockList.add(mock);
			}
			
            pStmt = conn.prepareStatement(homu);

            // SELECTを実行し、結果表を取得
            rs = pStmt.executeQuery();

            // 一致したユーザーが存在した場合
            while(rs.next()) {
                // 結果表からデータを取得
                String ysen = rs.getString("am_year_season_exam_number");
                String field = rs.getString("field");
                String middleCategory = rs.getString("middle_category");
                String smallCategory = rs.getString("small_category");
                String answer = rs.getString("answer");
                String userAnswer = "";
                int isAnswered = 0;
                Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
                mockNo++;
                mockList.add(mock);
            }
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
			return mockList;
	}
	
	public void mockInsert(Mock mock) {
		// データベースへ接続
		try (Connection conn = DriverManager.getConnection(
		        JDBC_URL, DB_USER, DB_PASS)) {
			
			// SELECT文を準備
			String sql = "INSERT INTO mock (mock_id, student_mail, mock_no, am_year_season_exam_number, field, middle_category, small_category, answer, user_answer, is_answered)"
					+ "VALUES(?, ?, ?, ?, ?, ?, ?, ?, '-', 0)";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			
			pStmt.setInt(1, mock.getMockId());
			pStmt.setString(2, mock.getStudentMail());
			pStmt.setInt(3, mock.getMockNo());
			pStmt.setString(4, mock.getYsen());
			pStmt.setString(5, mock.getField());
			pStmt.setString(6, mock.getMiddleCategory());
			pStmt.setString(7, mock.getSmallCategory());
			pStmt.setString(8, mock.getAnswer());
			
			pStmt.executeUpdate();
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void updateUserAnswer(int mockId, String userAnswer, int mockNo) {
		// データベースへ接続
		try (Connection conn = DriverManager.getConnection(
		        JDBC_URL, DB_USER, DB_PASS)) {
			// SELECT文を準備
			String sql = "UPDATE mock SET user_answer = ?, is_answered = 1 WHERE mock_id = ? AND mock_no = ?";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			
			pStmt.setString(1, userAnswer);
			pStmt.setInt(2, mockId);
			pStmt.setInt(3, mockNo + 1);
			
			pStmt.executeUpdate();
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public int maxMockId() {
		int maxMockId = -1;

		// データベースへ接続
		try (Connection conn = DriverManager.getConnection(
		        JDBC_URL, DB_USER, DB_PASS)) {
			
			// SELECT文を準備
			String sql = "SELECT MAX(mock_id) + 1 AS max_mock_id FROM mock";
			PreparedStatement pStmt = conn.prepareStatement(sql);

			// SELECTを実行し、結果表を取得
			ResultSet rs = pStmt.executeQuery();

			// 一致したユーザーが存在した場合
			// そのユーザーを表すEmployeeインスタンスを生成
			while(rs.next()) {
				maxMockId = rs.getInt("max_mock_id");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return -1;
		}
			// 見つかったユーザーまたはnullを返す
			return maxMockId;
	}
	
	public List<Mock> selectMock(int mockId) {
		List<Mock> mockList = new ArrayList<Mock>();

		// データベースへ接続
		try (Connection conn = DriverManager.getConnection(
		        JDBC_URL, DB_USER, DB_PASS)) {

			// SELECT文を準備
			String sql = "SELECT * FROM mock WHERE mock_id = ? AND mock_no <> 0";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setInt(1, mockId);

			// SELECTを実行し、結果表を取得
			ResultSet rs = pStmt.executeQuery();

			while(rs.next()) {
				// 結果表からデータを取得
				String studentMail = rs.getString("student_mail");
				int mockNo = rs.getInt("mock_no");
				String ysen = rs.getString("am_year_season_exam_number");
				String field = rs.getString("field");
				String middleCategory = rs.getString("middle_category");
				String smallCategory = rs.getString("small_category");
				String answer = rs.getString("answer");
				String userAnswer = rs.getString("user_answer");
				int isAnswered = rs.getInt("is_answered");
				Mock mock = new Mock(mockId, studentMail, mockNo, ysen, field, middleCategory, smallCategory, answer, userAnswer, isAnswered);
				
				mockList.add(mock);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
			// 見つかったユーザーまたはnullを返す
			return mockList;
	}
	
}
