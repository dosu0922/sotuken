package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Incorrect;
import model.Mock;

public class IncorrectDAO extends DAOParam{	
	public List<Incorrect> incorrectDisplay(String studentMail) {
		List<Incorrect> incorrectList = new ArrayList<Incorrect>();

		// データベースへ接続
		try (Connection conn = DriverManager.getConnection(
		        JDBC_URL, DB_USER, DB_PASS)) {

			// SELECT文を準備
			String sql = "SELECT * FROM incorrect WHERE student_mail = ? AND correctness = '×'";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setString(1, studentMail);
			
			// SELECTを実行し、結果表を取得
			ResultSet rs = pStmt.executeQuery();

			while(rs.next()) {
				// 結果表からデータを取得
				String correctness = rs.getString("correctness");
				String ysen = rs.getString("am_year_season_exam_number");
				
				Incorrect incorrect = new Incorrect(studentMail, correctness, ysen);
				incorrectList.add(incorrect);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
			// 見つかったユーザーまたはnullを返す
			return incorrectList;
	}
	
	public List<Incorrect> selectIncorrect(int gradeId, String studentMail) {
		List<Incorrect> incorrectList = new ArrayList<Incorrect>();

		// データベースへ接続
		try (Connection conn = DriverManager.getConnection(
		        JDBC_URL, DB_USER, DB_PASS)) {

			// SELECT文を準備
			String sql = "SELECT * FROM grade WHERE student_mail = ? AND grade_id = ? AND mock_no <> 0 AND correctness = '×'";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setString(1, studentMail);
			pStmt.setInt(2, gradeId);
			
			// SELECTを実行し、結果表を取得
			ResultSet rs = pStmt.executeQuery();

			while(rs.next()) {
				// 結果表からデータを取得
				String correctness = rs.getString("correctness");
				String ysen = rs.getString("am_year_season_exam_number");
				
				Incorrect incorrect = new Incorrect(studentMail, correctness, ysen);
				incorrectList.add(incorrect);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
			// 見つかったユーザーまたはnullを返す
			return incorrectList;
	}
	
	public void incorrectInsert(Mock mock) {

		// データベースへ接続
		try (Connection conn = DriverManager.getConnection(
		        JDBC_URL, DB_USER, DB_PASS)) {

			String sql = "INSERT INTO incorrect (student_mail, correctness, am_year_season_exam_number) VALUES (?,?,?)";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setString(1, mock.getStudentMail());
			pStmt.setString(2, "×");
			pStmt.setString(3, mock.getYsen());
			
			pStmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void correctUpdate(Incorrect incorrect) {
		// データベースへ接続
		try (Connection conn = DriverManager.getConnection(
		        JDBC_URL, DB_USER, DB_PASS)) {

			String sql = "DELETE FROM incorrect WHERE am_year_season_exam_number = ?";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setString(1, incorrect.getYsen());

			pStmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
