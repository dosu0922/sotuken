package dao;

public class DAOParam{
	//DB SETTING
	protected final String DB_NAME = "ETP";
	protected final String DB_USER = "root";
	protected final String DB_PASS = "password";
	//MySQL URL
	protected final String JDBC_URL = "jdbc:mysql://localhost/" + DB_NAME;
}