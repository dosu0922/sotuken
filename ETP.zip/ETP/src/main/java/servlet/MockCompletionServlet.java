package servlet;

import java.io.IOException;
import java.util.List;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Grade;
import model.InsertGrade;
import model.InsertIncorrect;
import model.Mock;
import model.SelectGrade;
import model.UpdateCorrectRate;

/**
 * Servlet implementation class MockCompletionServlet
 */
public class MockCompletionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MockCompletionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher =
				request.getRequestDispatcher("/WEB-INF/jsp/kokkaMenu.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		List<Mock> mockList = (List<Mock>)session.getAttribute("mockList");
		
		/*boolean containsZero = false;
        for (Mock mock : mockList) {
        	// 仮定: value フィールドが0であるかどうかを判定
        	if (mock.getIsAnswered() == 0) {
            	containsZero = true;
                break; // 0が見つかったらループを抜ける
            }
        }
        
        if(containsZero) {
        	RequestDispatcher dispatcher =
        			request.getRequestDispatcher("/WEB-INF/jsp/mockConfirm.jsp");
        	dispatcher.forward(request, response);
        }*/
        
		//成績の反映
		InsertGrade ig = new InsertGrade();
		ig.insertGrade(mockList);
		
		//正答率の反映
		UpdateCorrectRate ucr = new UpdateCorrectRate();
		ucr.updateCorrectRate(mockList);
		
		//不正解問題の反映
		InsertIncorrect ii = new InsertIncorrect();
		ii.incorrectInsert(mockList);
		
		//成績の取得
		int gradeId = (int)session.getAttribute("mockId");
		SelectGrade sg = new SelectGrade();
		List<Grade> gradeList = sg.selectGrade(gradeId);
		
		session.setAttribute("gradeList", gradeList);
		
		session.setAttribute("isMock", false);
		session.setAttribute("isIncorrect", false);
		
		session.removeAttribute("mockList");
		
		RequestDispatcher dispatcher =
				request.getRequestDispatcher("/WEB-INF/jsp/grade.jsp");
		dispatcher.forward(request, response);
	}

}
