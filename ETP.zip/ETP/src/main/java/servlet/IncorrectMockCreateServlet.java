package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.CorrectRate;
import model.Incorrect;
import model.SelectCorrectRate;
import model.SelectIncorrect;
import model.YsenReplaceLogic;

/**
 * Servlet implementation class IncorrectMockCreateServlet
 */
public class IncorrectMockCreateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public IncorrectMockCreateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		SelectIncorrect si = new SelectIncorrect();
		String studentMail = (String) session.getAttribute("studentMail");
		List<Incorrect> incorrectList = new ArrayList<>();
		incorrectList = si.selectIncorrect(studentMail);
		
		
		String ysen = incorrectList.get(0).getYsen();
		//正答率の取得
		CorrectRate correctRate = new CorrectRate();
		SelectCorrectRate scr = new SelectCorrectRate();
		correctRate = scr.selectCorrectRate(ysen);
		session.setAttribute("correctRate", correctRate);
		
		YsenReplaceLogic yrl = new YsenReplaceLogic();
		
		//年度時期を分ける
		ysen = yrl.ysenReplace(ysen);
		String[] ysenSplit = ysen.split("/");
		String year = ysenSplit[0];
		String examNo = ysenSplit[1];
		Integer incorrectCount = 0;
		
		//不正解問題出題中かどうか
		Boolean isMock = false;
		Boolean isIncorrect = true;
		session.setAttribute("isMock", isMock);
		session.setAttribute("isIncorrect", isIncorrect);
		
		//不正解問題のサイズを登録
		Integer incorrectSize = incorrectList.size();
		session.setAttribute("incorrectSize", incorrectSize);
		
		session.setAttribute("incorrectList", incorrectList);
		session.setAttribute("incorrectCount", incorrectCount);
		
		
		//何週目かを登録
		Integer incorrectTimes = (Integer) session.getAttribute("incorrectTimes");
		if(incorrectTimes == null) {
			session.setAttribute("incorrectTimes", 1);
		} else {
			session.setAttribute("incorrectTimes", incorrectTimes + 1);
		}

		String path = "/WEB-INF/" + year + "/jsp/q" + examNo + ".jsp";
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(path);
    	dispatcher.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
