package servlet;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Incorrect;
import model.SelectIncorrect;

/**
 * Servlet implementation class IncorrectMockMenuServlet
 */
public class IncorrectMockMenuServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public IncorrectMockMenuServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		SelectIncorrect si = new SelectIncorrect();
		List<Incorrect> incorrectList = (List<Incorrect>) session.getAttribute("incorrectList");
		String studentMail = (String) session.getAttribute("studentMail");
		incorrectList = si.selectIncorrect(studentMail);
		session.setAttribute("incorrectList", incorrectList);
		
		session.setAttribute("isMock", false);
		session.setAttribute("isIncorrect", false);
		
		RequestDispatcher dispatcher =
    			request.getRequestDispatcher("/WEB-INF/jsp/incorrectMockMenu.jsp");
    	dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
