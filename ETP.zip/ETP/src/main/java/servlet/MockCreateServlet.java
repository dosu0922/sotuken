package servlet;

import java.io.IOException;
import java.util.List;
import dao.MockDAO;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.CorrectRate;
import model.InsertMock;
import model.Mock;
import model.SelectCorrectRate;
import model.YsenReplaceLogic;

/**
 * Servlet implementation class MockCreateServlet
 */
public class MockCreateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MockCreateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		List<Mock> mockList = (List<Mock>)session.getAttribute("mockList");
		
		if(mockList != null) {
		  response.sendRedirect("/ETP/MockExecutionServlet");
		} else {  		  
    		//一番大きい成績IDを取得
    		MockDAO modao = new MockDAO();
    		int mockId = modao.maxMockId();
    		session.setAttribute("mockId", mockId);
    		
    		//模試を作成
    		String studentMail = (String) session.getAttribute("studentMail");
    		mockList = modao.MockCreate(mockId, studentMail);
    	    for(int i= 0; i < mockList.size(); i++) {
                System.out.println(i + "個目:" + mockList.get(i).getYsen());
          }
    		session.setAttribute("mockList", mockList);
    		
    		//模試を登録
    		InsertMock im = new InsertMock();
    		im.insertMock(mockList);
    		
    		//問番号登録
    		session.setAttribute("mockNo", 0);
    		
    		//正答率の取得
    		CorrectRate correctRate = new CorrectRate();
    		String ysen = mockList.get(0).getYsen();
    		SelectCorrectRate scr = new SelectCorrectRate();
    		correctRate = scr.selectCorrectRate(ysen);
    		session.setAttribute("correctRate", correctRate);
    		
    		YsenReplaceLogic yrl = new YsenReplaceLogic();
    		
    		//年度時期を分ける
    		ysen = yrl.ysenReplace(ysen);
    		String[] ysenSplit = ysen.split("/");
    		String year = ysenSplit[0];
    		String examNo = ysenSplit[1];
    		
    		//模試かどうか
    		Boolean isMock = true;
    		Boolean isIncorrect = false;
    		session.setAttribute("isMock", isMock);
    		session.setAttribute("isIncorrect", isIncorrect);
    		
    		String path = "/WEB-INF/" + year + "/jsp/q" + examNo + ".jsp";
    		
    		System.out.println(path);
    		
    		RequestDispatcher dispatcher = request.getRequestDispatcher(path);
        	dispatcher.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
