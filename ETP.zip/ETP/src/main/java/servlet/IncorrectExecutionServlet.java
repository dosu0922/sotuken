package servlet;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.CorrectRate;
import model.Incorrect;
import model.SelectCorrectRate;
import model.SelectIncorrect;
import model.UpdateIncorrect;
import model.YsenReplaceLogic;

/**
 * Servlet implementation class IncorrectExecutionServlet
 */
public class IncorrectExecutionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public IncorrectExecutionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		Integer incorrectCount = (Integer) session.getAttribute("incorrectCount");
		Integer incorrectSize = (Integer) session.getAttribute("incorrectSize");
		List<Incorrect> incorrectList = (List<Incorrect>) session.getAttribute("incorrectList");
		
		String ysen = incorrectList.get(incorrectCount).getYsen();
		
		//正答率の取得
		CorrectRate correctRate = new CorrectRate();
		SelectCorrectRate scr = new SelectCorrectRate();
		correctRate = scr.selectCorrectRate(ysen);
		session.setAttribute("correctRate", correctRate);
		
		YsenReplaceLogic yrl = new YsenReplaceLogic();
		
		//年度時期を分ける
		ysen = yrl.ysenReplace(ysen);
		String[] ysenSplit = ysen.split("/");
		String year = ysenSplit[0];
		String examNo = ysenSplit[1];
		//不正解問題のサイズを登録
		incorrectSize = incorrectList.size();
		session.setAttribute("incorrectSize", incorrectSize);
		
		session.setAttribute("incorrectList", incorrectList);
		session.setAttribute("incorrectCount", incorrectCount);
		
		String path = "/WEB-INF/" + year + "/jsp/q" + examNo + ".jsp";
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(path);
    	dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		Integer incorrectCount = (Integer) session.getAttribute("incorrectCount");
		Integer incorrectSize = (Integer) session.getAttribute("incorrectSize");
		Integer incorrectTimes = (Integer) session.getAttribute("incorrectTimes");
		List<Incorrect> incorrectList = (List<Incorrect>) session.getAttribute("incorrectList");
		
		String userAnswer = request.getParameter("userAnswer");
		
		//正誤の反映
		UpdateIncorrect ui = new UpdateIncorrect();
		
		if(userAnswer.equals("maru")) {
			ui.correctUpdate(incorrectList.get(incorrectCount));	//正解ならDB更新
		}
		
		//問題が終わる場合
		SelectIncorrect si = new SelectIncorrect();
		String studentMail = (String) session.getAttribute("studentMail");

		int result = incorrectCount.compareTo(incorrectSize - 1);
		
		if(result == 0) {	//全問解いた場合
			incorrectList = si.selectIncorrect(studentMail);
			session.setAttribute("incorrectList", incorrectList);
			
			RequestDispatcher dispatcher =
					request.getRequestDispatcher("/WEB-INF/jsp/complete.jsp");
			dispatcher.forward(request, response);
		} else {	//問題が続く場合
			incorrectCount++;
			String ysen = incorrectList.get(incorrectCount).getYsen();
			
			//正答率の取得
			CorrectRate correctRate = new CorrectRate();
			SelectCorrectRate scr = new SelectCorrectRate();
			correctRate = scr.selectCorrectRate(ysen);
			session.setAttribute("correctRate", correctRate);
			
			YsenReplaceLogic yrl = new YsenReplaceLogic();
			
			//年度時期を分ける
			ysen = yrl.ysenReplace(ysen);
			String[] ysenSplit = ysen.split("/");
			String year = ysenSplit[0];
			String examNo = ysenSplit[1];
			//不正解問題のサイズを登録
			incorrectSize = incorrectList.size();
			session.setAttribute("incorrectSize", incorrectSize);
			
			session.setAttribute("incorrectList", incorrectList);
			session.setAttribute("incorrectCount", incorrectCount);
			
			String path = "/WEB-INF/" + year + "/jsp/q" + examNo + ".jsp";
			
			RequestDispatcher dispatcher = request.getRequestDispatcher(path);
	    	dispatcher.forward(request, response);
		}
	}

}
