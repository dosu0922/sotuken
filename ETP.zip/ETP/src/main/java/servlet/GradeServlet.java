package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Grade;
import model.SelectGrade;

/**
 * Servlet implementation class GradeServlet
 */
public class GradeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GradeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		SelectGrade sg = new SelectGrade();
		
		List<Grade> allGradeList = new ArrayList<Grade>();
		List<Integer> gradeIdList = new ArrayList<Integer>();
		
		String studentMail = (String) session.getAttribute("studentMail");
		allGradeList = sg.selectGrade(studentMail);
		gradeIdList = sg.selectGradeId(studentMail);
		
		session.setAttribute("gradeList", allGradeList);
		session.setAttribute("gradeIdList", gradeIdList);
		
		RequestDispatcher dispatcher =
    			request.getRequestDispatcher("/WEB-INF/jsp/allGrade.jsp");
    	dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		int gradeId =  Integer.parseInt(request.getParameter("gradeId"));
		
		if(gradeId == -1) {
			response.sendRedirect("/ETP/GradeServlet");
		} else {
			HttpSession session = request.getSession();
			SelectGrade sg = new SelectGrade();
			
			List<Grade> filterGradeList = new ArrayList<Grade>();
			String studentMail = (String) session.getAttribute("studentMail");
			filterGradeList = sg.filterGrade(studentMail, gradeId);
			
			session.setAttribute("gradeList", filterGradeList);
			
			RequestDispatcher dispatcher =
	    			request.getRequestDispatcher("/WEB-INF/jsp/allGrade.jsp");
	    	dispatcher.forward(request, response);
		}
	}

}
