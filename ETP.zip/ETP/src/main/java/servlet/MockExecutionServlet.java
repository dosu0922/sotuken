package servlet;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.CorrectRate;
import model.Mock;
import model.SelectCorrectRate;
import model.SelectMock;
import model.UpdateMock;
import model.YsenReplaceLogic;

/**
 * Servlet implementation class MockExecutionServlet
 */
public class MockExecutionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MockExecutionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int mockNo;
		try {
			mockNo = Integer.parseInt(request.getParameter("mockNo"));
		} catch (NumberFormatException e) {
			mockNo = 0;
		}
		
		
		HttpSession session = request.getSession();
		List<Mock> mockList = (List<Mock>) session.getAttribute("mockList");
		

		String ysen = mockList.get(mockNo).getYsen();
		
		//正答率の取得
		SelectCorrectRate scr = new SelectCorrectRate();
		CorrectRate correctRate = scr.selectCorrectRate(ysen);
		session.setAttribute("correctRate", correctRate);
		
		//年度時期を分ける
		YsenReplaceLogic yrl = new YsenReplaceLogic();
		ysen = yrl.ysenReplace(ysen);
		String[] ysenSplit = ysen.split("/");
		String year = ysenSplit[0];
		String examNo = ysenSplit[1];
		
		session.setAttribute("mockNo", mockNo);
		
		//mockListを更新
		SelectMock sm = new SelectMock();
		int mockId = (int) session.getAttribute("mockId");
		mockList = sm.selectMock(mockId);
		System.out.println("size：" + mockList.size());
		session.setAttribute("mockList", mockList);
		
		//模試かどうか
		Boolean isMock = true;
		Boolean isIncorrect = false;
		session.setAttribute("isMock", isMock);
		session.setAttribute("isIncorrect", isIncorrect);
		
		String path = "/WEB-INF/" + year + "/jsp/q" + examNo + ".jsp";
		RequestDispatcher dispatcher =
    			request.getRequestDispatcher(path);
    	dispatcher.forward(request, response);	
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		int mockNo = (int) session.getAttribute("mockNo");
		List<Mock> mockList = (List<Mock>) session.getAttribute("mockList");
		String userAnswer = request.getParameter("userAnswer");
		
		//ユーザーの解答を更新
		UpdateMock um = new UpdateMock();
		um.updateUserAnswer(mockList.get(mockNo).getMockId(), userAnswer, mockNo);
		
		String ysen = mockList.get(mockNo).getYsen();
		
		//正答率の取得
		SelectCorrectRate scr = new SelectCorrectRate();
		CorrectRate correctRate = scr.selectCorrectRate(ysen);
		session.setAttribute("correctRate", correctRate);
		
		//年度時期を分ける
		YsenReplaceLogic yrl = new YsenReplaceLogic();
		ysen = yrl.ysenReplace(ysen);
		String[] ysenSplit = ysen.split("/");
		String year = ysenSplit[0];
		String examNo = ysenSplit[1];
		
		//表示のためのセッション登録
		session.setAttribute("mockNo", mockNo);
		
		//mockListを更新
		SelectMock sm = new SelectMock();
		int mockId = (int) session.getAttribute("mockId");
		mockList = sm.selectMock(mockId);
		System.out.println("size：" + mockList.size());
		session.setAttribute("mockList", mockList);
		
		String path = "/WEB-INF/" + year + "/jsp/q" + examNo + ".jsp";
		
		//模試かどうか
		Boolean isMock = true;
		Boolean isIncorrect = false;
		session.setAttribute("isMock", isMock);
		session.setAttribute("isIncorrect", isIncorrect);
		
		RequestDispatcher dispatcher =
    			request.getRequestDispatcher(path);
    	dispatcher.forward(request, response);
	}
}
