package servlet;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.CorrectRate;
import model.SelectCorrectRate;
import model.YsenReplaceLogic;

/**
 * Servlet implementation class PastExamNoServlet
 */
public class PastExamNoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PastExamNoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String year = request.getParameter("year");
		String exam_no = request.getParameter("exam_no");
		
		if (year != null && exam_no != null) {
			HttpSession session = request.getSession();
			Boolean isMock = false;
			Boolean isIncorrect = false;
			
			session.setAttribute("isMock", isMock);
			session.setAttribute("isIncorrect", isIncorrect);
			
			//正答率を取得するためにysenに変換する
			YsenReplaceLogic yrl = new YsenReplaceLogic();
			String ysen = "";
			ysen = yrl.yearAndExamNoReplace(year, exam_no);
			
			//正答率の取得
			CorrectRate correctRate = new CorrectRate();
			SelectCorrectRate scr = new SelectCorrectRate();
			correctRate = scr.selectCorrectRate(ysen);
			session.setAttribute("correctRate", correctRate);
			
			String path = "/WEB-INF/" + year + "/jsp/q" + exam_no +".jsp";
			
			session.setAttribute("isMock", false);
			session.setAttribute("isIncorrect", false);
			
			RequestDispatcher dispatcher = request.getRequestDispatcher(path);
			dispatcher.forward(request, response);
		} else {
			RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/pastExamMenu.jsp");
			dispatcher.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
